const ProductsComponent = () => {};

export default ProductsComponent;
